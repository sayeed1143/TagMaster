# TagMaster - AI-Powered Social Media Tag Generator

## Overview

TagMaster is a modern web application that generates optimized hashtags and tags for social media platforms using AI-powered algorithms. The application supports YouTube (tags and hashtags), Instagram, and TikTok, providing SEO-optimized results to maximize content discoverability.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom CSS variables and neon theme
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite with React plugin and runtime error overlay

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Session Management**: In-memory storage (MemStorage class)
- **API**: RESTful endpoints with JSON responses

### UI/UX Design
- **Design System**: Dark theme with neon accents (cyan, pink, purple, yellow)
- **Layout**: Responsive design with mobile-first approach
- **Animations**: CSS animations with glass morphism effects
- **Accessibility**: ARIA labels and semantic HTML structure

## Key Components

### Database Schema
- **Tag Generations Table**: Stores generated tags with platform, description, and results
- **Fields**: id (serial), platform (text), description (text), generatedTags (jsonb), createdAt (timestamp)
- **Supported Platforms**: youtube-tags, youtube-hashtags, instagram, tiktok

### API Endpoints
- `POST /api/generate-tags`: Generate tags for a specific platform and description
- `GET /api/recent-generations`: Retrieve recent tag generations (limit 10)

### Core Services
- **TagGeneratorService**: Handles tag generation logic for different platforms
- **Storage Service**: Manages data persistence with in-memory implementation
- **Platform-specific Algorithms**: Customized tag generation for each social media platform

### Frontend Components
- **PlatformSelector**: Multi-platform selection interface
- **TagGenerator**: Input form and generation logic
- **TagResults**: Display and copy functionality for generated tags
- **FeaturesShowcase**: Marketing section with feature highlights

## Data Flow

1. **User Input**: User selects platform and enters content description
2. **Validation**: Client-side validation using Zod schemas
3. **API Request**: Frontend sends POST request to `/api/generate-tags`
4. **Tag Generation**: Server processes request using TagGeneratorService
5. **Storage**: Generated tags stored in memory storage
6. **Response**: Server returns generated tags with metadata
7. **Display**: Frontend displays results with copy functionality
8. **History**: Recent generations accessible via separate endpoint

## External Dependencies

### Frontend Dependencies
- **React Ecosystem**: React, React DOM, React Query
- **UI Components**: Radix UI primitives, Lucide React icons
- **Styling**: Tailwind CSS, Class Variance Authority, clsx
- **Forms**: React Hook Form with Hookform Resolvers
- **Utilities**: date-fns, nanoid

### Backend Dependencies
- **Server**: Express.js with middleware
- **Database**: Drizzle ORM, Neon serverless client
- **Validation**: Zod schemas
- **Session**: connect-pg-simple (for future PostgreSQL sessions)

### Development Dependencies
- **Build Tools**: Vite, esbuild, TypeScript
- **Database Tools**: Drizzle Kit for migrations
- **Development**: tsx for TypeScript execution

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations in `migrations/` directory

### Environment Configuration
- **Database**: PostgreSQL connection via `DATABASE_URL` environment variable
- **Development**: Hot module replacement with Vite dev server
- **Production**: Static file serving with Express.js

### Platform Support
- **Development**: Replit environment with cartographer plugin
- **Production**: Node.js server with static file serving
- **Database**: Neon serverless PostgreSQL for scalability

## Changelog

```
Changelog:
- July 07, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```