import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tagGenerations = pgTable("tag_generations", {
  id: serial("id").primaryKey(),
  platform: text("platform").notNull(), // 'youtube-tags', 'youtube-hashtags', 'instagram', 'tiktok'
  description: text("description").notNull(),
  generatedTags: jsonb("generated_tags").notNull(), // array of strings
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTagGenerationSchema = createInsertSchema(tagGenerations).pick({
  platform: true,
  description: true,
});

export type InsertTagGeneration = z.infer<typeof insertTagGenerationSchema>;
export type TagGeneration = typeof tagGenerations.$inferSelect;

// Platform types
export const PlatformType = z.enum(['youtube-tags', 'youtube-hashtags', 'instagram', 'tiktok']);
export type PlatformType = z.infer<typeof PlatformType>;

// API Response types
export const TagGenerationRequest = z.object({
  platform: PlatformType,
  description: z.string().min(10, "Description must be at least 10 characters"),
});

export type TagGenerationRequest = z.infer<typeof TagGenerationRequest>;

export const TagGenerationResponse = z.object({
  id: z.number(),
  platform: PlatformType,
  description: z.string(),
  generatedTags: z.array(z.string()),
  createdAt: z.string(),
});

export type TagGenerationResponse = z.infer<typeof TagGenerationResponse>;
