import { tagGenerations, type TagGeneration, type InsertTagGeneration } from "@shared/schema";

export interface IStorage {
  createTagGeneration(generation: InsertTagGeneration & { generatedTags: string[] }): Promise<TagGeneration>;
  getTagGeneration(id: number): Promise<TagGeneration | undefined>;
  getRecentTagGenerations(limit?: number): Promise<TagGeneration[]>;
}

export class MemStorage implements IStorage {
  private tagGenerations: Map<number, TagGeneration>;
  private currentId: number;

  constructor() {
    this.tagGenerations = new Map();
    this.currentId = 1;
  }

  async createTagGeneration(insertGeneration: InsertTagGeneration & { generatedTags: string[] }): Promise<TagGeneration> {
    const id = this.currentId++;
    const generation: TagGeneration = {
      ...insertGeneration,
      id,
      createdAt: new Date(),
    };
    this.tagGenerations.set(id, generation);
    return generation;
  }

  async getTagGeneration(id: number): Promise<TagGeneration | undefined> {
    return this.tagGenerations.get(id);
  }

  async getRecentTagGenerations(limit: number = 10): Promise<TagGeneration[]> {
    return Array.from(this.tagGenerations.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
