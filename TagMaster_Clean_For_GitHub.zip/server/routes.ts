import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { tagGeneratorService } from "./services/tag-generator";
import { TagGenerationRequest, PlatformType } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Generate tags endpoint
  app.post("/api/generate-tags", async (req, res) => {
    try {
      const { platform, description } = TagGenerationRequest.parse(req.body);
      
      // Generate tags using the service
      const generatedTags = await tagGeneratorService.generateTags(platform, description);
      
      // Store the generation in memory
      const tagGeneration = await storage.createTagGeneration({
        platform,
        description,
        generatedTags,
      });
      
      res.json({
        id: tagGeneration.id,
        platform: tagGeneration.platform,
        description: tagGeneration.description,
        generatedTags: tagGeneration.generatedTags,
        createdAt: tagGeneration.createdAt.toISOString(),
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Invalid request data", 
          errors: error.errors 
        });
      } else {
        console.error("Tag generation error:", error);
        res.status(500).json({ 
          message: "Failed to generate tags. Please try again." 
        });
      }
    }
  });

  // Get recent generations endpoint
  app.get("/api/recent-generations", async (req, res) => {
    try {
      const generations = await storage.getRecentTagGenerations(10);
      res.json(generations.map(gen => ({
        id: gen.id,
        platform: gen.platform,
        description: gen.description,
        generatedTags: gen.generatedTags,
        createdAt: gen.createdAt.toISOString(),
      })));
    } catch (error) {
      console.error("Failed to fetch recent generations:", error);
      res.status(500).json({ 
        message: "Failed to fetch recent generations" 
      });
    }
  });

  // Get specific generation endpoint
  app.get("/api/generation/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid generation ID" });
      }
      
      const generation = await storage.getTagGeneration(id);
      if (!generation) {
        return res.status(404).json({ message: "Generation not found" });
      }
      
      res.json({
        id: generation.id,
        platform: generation.platform,
        description: generation.description,
        generatedTags: generation.generatedTags,
        createdAt: generation.createdAt.toISOString(),
      });
    } catch (error) {
      console.error("Failed to fetch generation:", error);
      res.status(500).json({ 
        message: "Failed to fetch generation" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
