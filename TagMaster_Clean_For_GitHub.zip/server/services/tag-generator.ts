import { PlatformType } from "@shared/schema";

export class TagGeneratorService {
  
  async generateTags(platform: PlatformType, description: string): Promise<string[]> {
    const keywords = this.extractKeywords(description);
    
    switch (platform) {
      case 'youtube-tags':
        return this.generateYoutubeTags(keywords, description);
      case 'youtube-hashtags':
        return this.generateYoutubeHashtags(keywords, description);
      case 'instagram':
        return this.generateInstagramHashtags(keywords, description);
      case 'tiktok':
        return this.generateTiktokHashtags(keywords, description);
      default:
        throw new Error(`Unsupported platform: ${platform}`);
    }
  }

  private extractKeywords(description: string): string[] {
    // Extract meaningful keywords from description
    const words = description.toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2)
      .filter(word => !this.isStopWord(word));
    
    return [...new Set(words)]; // Remove duplicates
  }

  private isStopWord(word: string): boolean {
    const stopWords = ['the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'had', 'her', 'was', 'one', 'our', 'out', 'day', 'get', 'has', 'him', 'his', 'how', 'its', 'may', 'new', 'now', 'old', 'see', 'two', 'way', 'who', 'boy', 'did', 'man', 'end', 'few', 'got', 'let', 'put', 'say', 'she', 'too', 'use'];
    return stopWords.includes(word);
  }

  private generateYoutubeTags(keywords: string[], description: string): string[] {
    const tags: string[] = [];
    
    // Add primary keywords
    keywords.slice(0, 5).forEach(keyword => {
      tags.push(keyword);
    });
    
    // Add compound keywords
    for (let i = 0; i < keywords.length - 1 && tags.length < 15; i++) {
      for (let j = i + 1; j < keywords.length && tags.length < 15; j++) {
        tags.push(`${keywords[i]} ${keywords[j]}`);
      }
    }
    
    // Add common YouTube SEO tags based on content type
    const seoTags = this.getYoutubeSeoTags(keywords);
    seoTags.forEach(tag => {
      if (tags.length < 20 && !tags.includes(tag)) {
        tags.push(tag);
      }
    });
    
    return tags.slice(0, 20);
  }

  private generateYoutubeHashtags(keywords: string[], description: string): string[] {
    const hashtags: string[] = [];
    
    // Add primary hashtags
    keywords.slice(0, 5).forEach(keyword => {
      hashtags.push(`#${keyword.replace(/\s+/g, '')}`);
    });
    
    // Add trending hashtags based on content
    const trendingHashtags = this.getYoutubeTrendingHashtags(keywords);
    trendingHashtags.forEach(hashtag => {
      if (hashtags.length < 15 && !hashtags.includes(hashtag)) {
        hashtags.push(hashtag);
      }
    });
    
    // Add general YouTube hashtags
    const generalHashtags = ['#youtube', '#youtuber', '#content', '#viral', '#trending'];
    generalHashtags.forEach(hashtag => {
      if (hashtags.length < 20 && !hashtags.includes(hashtag)) {
        hashtags.push(hashtag);
      }
    });
    
    return hashtags.slice(0, 20);
  }

  private generateInstagramHashtags(keywords: string[], description: string): string[] {
    const hashtags: string[] = [];
    
    // Add primary hashtags
    keywords.slice(0, 5).forEach(keyword => {
      hashtags.push(`#${keyword.replace(/\s+/g, '')}`);
    });
    
    // Add Instagram-specific hashtags
    const instagramTags = this.getInstagramTrendingTags(keywords);
    instagramTags.forEach(hashtag => {
      if (hashtags.length < 18 && !hashtags.includes(hashtag)) {
        hashtags.push(hashtag);
      }
    });
    
    // Add engagement hashtags
    const engagementTags = ['#instagood', '#photooftheday'];
    engagementTags.forEach(hashtag => {
      if (hashtags.length < 20 && !hashtags.includes(hashtag)) {
        hashtags.push(hashtag);
      }
    });
    
    return hashtags.slice(0, 20);
  }

  private generateTiktokHashtags(keywords: string[], description: string): string[] {
    const hashtags: string[] = [];
    
    // Add primary hashtags
    keywords.slice(0, 5).forEach(keyword => {
      hashtags.push(`#${keyword.replace(/\s+/g, '')}`);
    });
    
    // Add TikTok trending hashtags
    const tiktokTags = this.getTiktokTrendingTags(keywords);
    tiktokTags.forEach(hashtag => {
      if (hashtags.length < 18 && !hashtags.includes(hashtag)) {
        hashtags.push(hashtag);
      }
    });
    
    // Add viral TikTok hashtags
    const viralTags = ['#fyp', '#foryou'];
    viralTags.forEach(hashtag => {
      if (hashtags.length < 20 && !hashtags.includes(hashtag)) {
        hashtags.push(hashtag);
      }
    });
    
    return hashtags.slice(0, 20);
  }

  private getYoutubeSeoTags(keywords: string[]): string[] {
    const contentTypes = {
      cooking: ['recipe', 'how to cook', 'cooking tips', 'food tutorial', 'kitchen hacks'],
      gaming: ['gameplay', 'gaming tips', 'walkthrough', 'game review', 'lets play'],
      fitness: ['workout', 'exercise', 'fitness tips', 'health', 'training'],
      music: ['music production', 'beats', 'tutorial', 'how to make music', 'daw'],
      tech: ['tech review', 'unboxing', 'gadget', 'technology', 'setup'],
      lifestyle: ['daily routine', 'lifestyle', 'vlog', 'day in the life', 'tips']
    };
    
    let tags: string[] = [];
    
    for (const [category, categoryTags] of Object.entries(contentTypes)) {
      const hasKeyword = keywords.some(keyword => 
        categoryTags.some(tag => tag.includes(keyword) || keyword.includes(tag.split(' ')[0]))
      );
      
      if (hasKeyword) {
        tags = [...tags, ...categoryTags];
        break;
      }
    }
    
    return tags;
  }

  private getYoutubeTrendingHashtags(keywords: string[]): string[] {
    const trendingMap = {
      cooking: ['#cooking', '#recipe', '#foodie', '#chef', '#homemade'],
      gaming: ['#gaming', '#gamer', '#gameplay', '#esports', '#gaminglife'],
      fitness: ['#fitness', '#workout', '#health', '#gym', '#fitnessmotivation'],
      music: ['#music', '#producer', '#beats', '#musician', '#audio'],
      tech: ['#tech', '#technology', '#gadgets', '#review', '#unboxing'],
      lifestyle: ['#lifestyle', '#vlog', '#daily', '#life', '#motivation']
    };
    
    let hashtags: string[] = [];
    
    for (const [category, categoryHashtags] of Object.entries(trendingMap)) {
      const hasKeyword = keywords.some(keyword => 
        keyword.includes(category) || category.includes(keyword)
      );
      
      if (hasKeyword) {
        hashtags = [...hashtags, ...categoryHashtags];
        break;
      }
    }
    
    return hashtags;
  }

  private getInstagramTrendingTags(keywords: string[]): string[] {
    const instagramMap = {
      cooking: ['#foodstagram', '#instafood', '#foodporn', '#delicious', '#yummy', '#foodblogger'],
      fashion: ['#fashion', '#style', '#ootd', '#fashionista', '#outfit', '#instafashion'],
      travel: ['#travel', '#wanderlust', '#explore', '#adventure', '#vacation', '#travelgram'],
      fitness: ['#fitnessmotivation', '#healthylifestyle', '#gymlife', '#fitspo', '#wellness'],
      photography: ['#photography', '#photooftheday', '#picoftheday', '#instaphoto', '#photographer'],
      lifestyle: ['#lifestyle', '#love', '#happy', '#beautiful', '#amazing', '#life']
    };
    
    let hashtags: string[] = [];
    
    for (const [category, categoryHashtags] of Object.entries(instagramMap)) {
      const hasKeyword = keywords.some(keyword => 
        keyword.includes(category) || category.includes(keyword)
      );
      
      if (hasKeyword) {
        hashtags = [...hashtags, ...categoryHashtags];
        break;
      }
    }
    
    // Add general popular Instagram hashtags
    hashtags = [...hashtags, '#instagram', '#insta', '#follow', '#like'];
    
    return hashtags;
  }

  private getTiktokTrendingTags(keywords: string[]): string[] {
    const tiktokMap = {
      cooking: ['#cooking', '#recipe', '#food', '#foodtok', '#cookinglife', '#chef'],
      dance: ['#dance', '#dancer', '#dancing', '#choreography', '#viral', '#trending'],
      comedy: ['#funny', '#comedy', '#meme', '#viral', '#trending', '#humor'],
      beauty: ['#beauty', '#makeup', '#skincare', '#beautytips', '#glowup'],
      fitness: ['#fitness', '#workout', '#gym', '#health', '#fit', '#fitnessmotivation'],
      lifestyle: ['#lifestyle', '#aesthetic', '#vibe', '#mood', '#life']
    };
    
    let hashtags: string[] = [];
    
    for (const [category, categoryHashtags] of Object.entries(tiktokMap)) {
      const hasKeyword = keywords.some(keyword => 
        keyword.includes(category) || category.includes(keyword)
      );
      
      if (hasKeyword) {
        hashtags = [...hashtags, ...categoryHashtags];
        break;
      }
    }
    
    // Add general TikTok hashtags
    hashtags = [...hashtags, '#tiktok', '#viral', '#trending', '#explore'];
    
    return hashtags;
  }
}

export const tagGeneratorService = new TagGeneratorService();
