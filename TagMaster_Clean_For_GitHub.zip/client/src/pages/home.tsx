import { useState } from "react";
import Logo from "@/components/logo";
import PlatformSelector from "@/components/platform-selector";
import TagGenerator from "@/components/tag-generator";
import FeaturesShowcase from "@/components/features-showcase";
import GoogleAdsPlaceholder from "@/components/google-ads-placeholder";
import { PlatformType } from "@shared/schema";

export default function Home() {
  const [selectedPlatform, setSelectedPlatform] = useState<PlatformType | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Background Effects */}
      <div className="fixed inset-0 bg-gradient-radial from-cyan-500/5 via-transparent to-pink-500/5"></div>
      
      {/* Header */}
      <header className="relative z-10 glass-morphism border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <Logo />
            
            {/* Ko-fi Support Button */}
            <a 
              href="#" 
              className="glass-morphism px-6 py-3 rounded-xl glow-button border border-yellow-500/30 hover:border-yellow-500/60 transition-all duration-300"
            >
              <span className="text-white font-medium">Support TagMaster on Ko-fi ☕</span>
            </a>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 pt-20 pb-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="animate-float">
            <h2 className="text-6xl sm:text-7xl lg:text-8xl font-bold mb-8">
              <span className="bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                Generate Perfect
              </span>
              <br />
              <span className="text-white">Social Media Tags</span>
            </h2>
            
            <p className="text-xl sm:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto leading-relaxed">
              Boost your content reach with AI-powered hashtags and tags for YouTube, Instagram, and TikTok. 
              <span className="text-cyan-500 font-semibold"> SEO-optimized</span> results in seconds.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <button 
                onClick={() => document.getElementById('generator-section')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-gradient-to-r from-cyan-500 to-purple-500 px-8 py-4 rounded-xl text-white font-bold text-lg glow-button hover:animate-pulse-glow transition-all duration-300"
              >
                <i className="fas fa-rocket mr-2"></i>
                Start Generating Tags
              </button>
              <button className="glass-morphism px-8 py-4 rounded-xl text-white font-medium border border-white/20 hover:border-white/40 transition-all duration-300">
                <i className="fas fa-play mr-2"></i>
                Watch Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Google Ads Placeholder 1 */}
      <GoogleAdsPlaceholder 
        type="banner" 
        label="SPONSORED" 
        description="Advertisement Space - Google Ads Integration"
        size="728x90 Banner Placement"
        borderColor="border-yellow-500/20"
      />

      {/* Platform Selection */}
      <section className="relative z-10 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold mb-6">
              Choose Your <span className="bg-gradient-to-r from-pink-500 to-yellow-500 bg-clip-text text-transparent">Platform</span>
            </h3>
            <p className="text-xl text-gray-300">Select the social media platform you want to optimize</p>
          </div>
          
          <PlatformSelector 
            selectedPlatform={selectedPlatform}
            onPlatformSelect={setSelectedPlatform}
          />
        </div>
      </section>

      {/* Tag Generation Interface */}
      <section id="generator-section" className="relative z-10 py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <TagGenerator selectedPlatform={selectedPlatform} />
        </div>
      </section>

      {/* Google Ads Placeholder 2 */}
      <GoogleAdsPlaceholder 
        type="medium-rectangle" 
        label="SPONSORED CONTENT" 
        description="Advertisement Space - Google Ads Integration"
        size="Medium Rectangle 300x250"
        borderColor="border-purple-500/20"
      />

      {/* Features Section */}
      <FeaturesShowcase />

      {/* Google Ads Placeholder 3 */}
      <GoogleAdsPlaceholder 
        type="leaderboard" 
        label="ADVERTISEMENT" 
        description="Advertisement Space - Google Ads Integration"
        size="Leaderboard 728x90 Banner"
        borderColor="border-cyan-500/20"
      />

      {/* Call to Action */}
      <section className="relative z-10 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="glass-morphism-strong rounded-3xl p-12 border border-white/20">
            <h3 className="text-4xl sm:text-5xl font-bold mb-6">
              Ready to <span className="bg-gradient-to-r from-cyan-500 to-pink-500 bg-clip-text text-transparent">Go Viral?</span>
            </h3>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Join thousands of creators who've boosted their reach with TagMaster's AI-powered tag generation
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <button 
                onClick={() => document.getElementById('generator-section')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 px-10 py-4 rounded-xl text-white font-bold text-lg glow-button hover:animate-pulse-glow transition-all duration-300 relative overflow-hidden"
              >
                <span className="relative z-10">
                  <i className="fas fa-rocket mr-2"></i>
                  Start Generating Now
                </span>
                <div className="absolute inset-0 shimmer-effect opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
              </button>
              
              <div className="text-center">
                <p className="text-sm text-gray-400">100% Free to Try</p>
                <p className="text-xs text-cyan-500">No sign-up required</p>
              </div>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-white/10">
              <div className="text-center">
                <div className="text-2xl font-bold text-cyan-500">50K+</div>
                <div className="text-sm text-gray-400">Tags Generated</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-500">1M+</div>
                <div className="text-sm text-gray-400">Views Boosted</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-pink-500">5K+</div>
                <div className="text-sm text-gray-400">Happy Creators</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 mt-20 glass-morphism border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <div className="text-3xl animate-lightning">⚡</div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-500 to-pink-500 bg-clip-text text-transparent">
                TagMaster
              </h1>
            </div>
            
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Empowering content creators with AI-powered social media optimization tools. 
              Generate perfect tags, boost your reach, and grow your audience effortlessly.
            </p>
            
            <div className="flex flex-wrap justify-center gap-8 text-sm text-gray-400">
              <a href="#" className="hover:text-cyan-500 transition-colors duration-300">Privacy Policy</a>
              <a href="#" className="hover:text-cyan-500 transition-colors duration-300">Terms of Service</a>
              <a href="#" className="hover:text-cyan-500 transition-colors duration-300">Contact Us</a>
              <a href="#" className="hover:text-cyan-500 transition-colors duration-300">API Documentation</a>
            </div>
            
            <div className="mt-8 pt-8 border-t border-white/10 text-sm text-gray-500">
              <p>&copy; 2025 TagMaster. All rights reserved. Made with ⚡ by creators, for creators.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
