export default function FeaturesShowcase() {
  const features = [
    {
      icon: "fas fa-brain",
      title: "AI-Powered Intelligence",
      description: "Advanced machine learning algorithms analyze trending content to suggest the most effective tags",
      color: "text-cyan-500",
      borderColor: "hover:border-cyan-500/30",
      delay: "0s"
    },
    {
      icon: "fas fa-rocket",
      title: "Instant Results", 
      description: "Generate 15-20 optimized tags in seconds. No waiting, no hassle, just results that work",
      color: "text-purple-500",
      borderColor: "hover:border-purple-500/30",
      delay: "0.5s"
    },
    {
      icon: "fas fa-chart-line",
      title: "SEO Optimized",
      description: "Every tag is crafted to maximize discoverability and boost your content's reach organically",
      color: "text-pink-500",
      borderColor: "hover:border-pink-500/30",
      delay: "1s"
    },
    {
      icon: "fas fa-users",
      title: "Multi-Platform Support",
      description: "Optimized for YouTube, Instagram, and TikTok with platform-specific algorithms",
      color: "text-yellow-500",
      borderColor: "hover:border-yellow-500/30",
      delay: "1.5s"
    },
    {
      icon: "fas fa-mobile-alt",
      title: "Mobile Optimized",
      description: "Perfect experience on any device with responsive design and touch-friendly controls",
      color: "text-green-400",
      borderColor: "hover:border-green-400/30",
      delay: "2s"
    },
    {
      icon: "fas fa-sync-alt",
      title: "Always Updated",
      description: "Our AI continuously learns from trending content to provide the most current tag suggestions",
      color: "text-blue-400",
      borderColor: "hover:border-blue-400/30",
      delay: "2.5s"
    }
  ];

  return (
    <section className="relative z-10 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h3 className="text-4xl font-bold mb-6">
            <span className="bg-gradient-to-r from-yellow-500 to-pink-500 bg-clip-text text-transparent">
              Why Choose TagMaster?
            </span>
          </h3>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">Advanced AI technology meets social media expertise to give you the edge</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className={`glass-morphism-strong rounded-2xl p-8 text-center border border-white/10 ${feature.borderColor} transition-all duration-300`}
            >
              <div 
                className={`text-5xl mb-6 animate-float ${feature.color}`}
                style={{ animationDelay: feature.delay }}
              >
                <i className={feature.icon}></i>
              </div>
              <h4 className="text-xl font-bold mb-4 text-white">{feature.title}</h4>
              <p className="text-gray-300">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
