import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { PlatformType, TagGenerationRequest, TagGenerationResponse } from "@shared/schema";
import TagResults from "./tag-results";

interface TagGeneratorProps {
  selectedPlatform: PlatformType | null;
}

export default function TagGenerator({ selectedPlatform }: TagGeneratorProps) {
  const [description, setDescription] = useState("");
  const [lastResult, setLastResult] = useState<TagGenerationResponse | null>(null);
  const { toast } = useToast();

  const generateTagsMutation = useMutation({
    mutationFn: async (data: TagGenerationRequest) => {
      const response = await apiRequest("POST", "/api/generate-tags", data);
      return await response.json() as TagGenerationResponse;
    },
    onSuccess: (data) => {
      setLastResult(data);
      toast({
        title: "Tags Generated Successfully!",
        description: `Generated ${data.generatedTags.length} optimized tags for ${data.platform.replace('-', ' ')}.`,
      });
    },
    onError: (error) => {
      console.error('Tag generation error:', error);
      toast({
        title: "Generation Failed",
        description: "Failed to generate tags. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!selectedPlatform) {
      toast({
        title: "Platform Required",
        description: "Please select a platform first.",
        variant: "destructive",
      });
      return;
    }

    if (description.length < 10) {
      toast({
        title: "Description Too Short",
        description: "Please provide at least 10 characters describing your content.",
        variant: "destructive",
      });
      return;
    }

    generateTagsMutation.mutate({
      platform: selectedPlatform,
      description: description.trim(),
    });
  };

  const getPlatformDisplayName = (platform: PlatformType | null) => {
    if (!platform) return "Select Platform";
    
    switch (platform) {
      case 'youtube-tags': return 'YouTube Tags';
      case 'youtube-hashtags': return 'YouTube #Hashtags';
      case 'instagram': return 'Instagram #Tags';
      case 'tiktok': return 'TikTok #Tags';
      default: return platform;
    }
  };

  return (
    <div className="glass-morphism-strong rounded-3xl p-8 lg:p-12 border border-white/20">
      <div className="text-center mb-8">
        <h3 className="text-3xl font-bold mb-4">
          <span className="bg-gradient-to-r from-cyan-500 to-purple-500 bg-clip-text text-transparent">
            AI Tag Generator
          </span>
        </h3>
        <p className="text-gray-300">Enter your content description and get SEO-optimized tags instantly</p>
        {selectedPlatform && (
          <div className="mt-4">
            <span className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400 border border-cyan-500/30">
              <i className="fas fa-target mr-2"></i>
              Generating for: {getPlatformDisplayName(selectedPlatform)}
            </span>
          </div>
        )}
      </div>
      
      {/* Input Section */}
      <div className="mb-8">
        <label className="block text-white font-medium mb-3">Describe Your Content</label>
        <textarea 
          className="w-full h-32 bg-slate-800/50 border border-white/20 rounded-xl px-6 py-4 text-white placeholder-gray-400 focus:border-cyan-500/60 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all duration-300 resize-none backdrop-blur-sm"
          placeholder="Example: A cooking tutorial showing how to make homemade pasta from scratch with traditional Italian techniques..."
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          maxLength={500}
        />
        <div className="text-right text-sm text-gray-400 mt-2">
          {description.length}/500 characters
        </div>
      </div>
      
      {/* Generate Button */}
      <div className="text-center mb-8">
        <button 
          onClick={handleGenerate}
          disabled={generateTagsMutation.isPending || !selectedPlatform}
          className="bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 px-12 py-4 rounded-xl text-white font-bold text-lg glow-button hover:animate-pulse-glow transition-all duration-300 relative overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <span className="relative z-10">
            {generateTagsMutation.isPending ? (
              <>
                <i className="fas fa-spinner mr-2 animate-spin"></i>
                Generating...
              </>
            ) : (
              <>
                <i className="fas fa-magic mr-2"></i>
                Generate Tags
              </>
            )}
          </span>
          {!generateTagsMutation.isPending && (
            <div className="absolute inset-0 shimmer-effect opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
          )}
        </button>
      </div>
      
      {/* Loading Animation */}
      {generateTagsMutation.isPending && (
        <div className="text-center py-8">
          <div className="inline-flex items-center">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-cyan-500 border-t-transparent mr-3"></div>
            <span className="text-cyan-500 font-medium">Generating optimized tags...</span>
          </div>
        </div>
      )}
      
      {/* Results Section */}
      {lastResult && !generateTagsMutation.isPending && (
        <TagResults result={lastResult} />
      )}
    </div>
  );
}
