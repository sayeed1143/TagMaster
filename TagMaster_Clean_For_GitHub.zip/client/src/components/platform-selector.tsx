import { PlatformType } from "@shared/schema";

interface PlatformSelectorProps {
  selectedPlatform: PlatformType | null;
  onPlatformSelect: (platform: PlatformType) => void;
}

export default function PlatformSelector({ selectedPlatform, onPlatformSelect }: PlatformSelectorProps) {
  return (
    <div className="grid md:grid-cols-3 gap-8 mb-16">
      {/* YouTube Card */}
      <div className="glass-morphism-strong rounded-2xl p-8 platform-card transition-all duration-300 cursor-pointer border border-red-500/20 hover:border-red-500/60">
        <div className="text-center">
          <div className="text-6xl mb-6">
            <i className="fab fa-youtube text-red-500"></i>
          </div>
          <h4 className="text-2xl font-bold mb-4 text-white">YouTube</h4>
          <p className="text-gray-300 mb-6">Generate optimized tags and hashtags for maximum discoverability</p>
          
          {/* YouTube Sub-options */}
          <div className="space-y-3">
            <button 
              onClick={() => onPlatformSelect('youtube-tags')}
              className={`w-full bg-gradient-to-r from-red-500 to-red-600 px-6 py-3 rounded-xl text-white font-medium glow-button transition-all duration-300 hover:from-red-400 hover:to-red-500 ${
                selectedPlatform === 'youtube-tags' ? 'ring-2 ring-red-400' : ''
              }`}
            >
              <i className="fas fa-tag mr-2"></i>
              Generate Tags
            </button>
            <button 
              onClick={() => onPlatformSelect('youtube-hashtags')}
              className={`w-full bg-gradient-to-r from-red-600 to-pink-600 px-6 py-3 rounded-xl text-white font-medium glow-button transition-all duration-300 hover:from-red-500 hover:to-pink-500 ${
                selectedPlatform === 'youtube-hashtags' ? 'ring-2 ring-pink-400' : ''
              }`}
            >
              <i className="fas fa-hashtag mr-2"></i>
              Generate #Hashtags
            </button>
          </div>
        </div>
      </div>
      
      {/* Instagram Card */}
      <div className="glass-morphism-strong rounded-2xl p-8 platform-card transition-all duration-300 cursor-pointer border border-pink-500/20 hover:border-pink-500/60">
        <div className="text-center">
          <div className="text-6xl mb-6">
            <i className="fab fa-instagram text-pink-500"></i>
          </div>
          <h4 className="text-2xl font-bold mb-4 text-white">Instagram</h4>
          <p className="text-gray-300 mb-6">Create trending hashtags to boost your post engagement</p>
          
          <button 
            onClick={() => onPlatformSelect('instagram')}
            className={`w-full bg-gradient-to-r from-pink-500 to-purple-600 px-6 py-3 rounded-xl text-white font-medium glow-button transition-all duration-300 hover:from-pink-400 hover:to-purple-500 ${
              selectedPlatform === 'instagram' ? 'ring-2 ring-pink-400' : ''
            }`}
          >
            <i className="fas fa-hashtag mr-2"></i>
            Generate #Tags
          </button>
        </div>
      </div>
      
      {/* TikTok Card */}
      <div className="glass-morphism-strong rounded-2xl p-8 platform-card transition-all duration-300 cursor-pointer border border-white/20 hover:border-white/60">
        <div className="text-center">
          <div className="text-6xl mb-6">
            <i className="fab fa-tiktok text-white"></i>
          </div>
          <h4 className="text-2xl font-bold mb-4 text-white">TikTok</h4>
          <p className="text-gray-300 mb-6">Viral hashtags to get your content on the For You page</p>
          
          <button 
            onClick={() => onPlatformSelect('tiktok')}
            className={`w-full bg-gradient-to-r from-gray-700 to-black px-6 py-3 rounded-xl text-white font-medium glow-button transition-all duration-300 hover:from-gray-600 hover:to-gray-800 ${
              selectedPlatform === 'tiktok' ? 'ring-2 ring-gray-400' : ''
            }`}
          >
            <i className="fas fa-hashtag mr-2"></i>
            Generate #Tags
          </button>
        </div>
      </div>
    </div>
  );
}
