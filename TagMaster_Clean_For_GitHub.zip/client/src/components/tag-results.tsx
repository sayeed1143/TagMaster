import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { TagGenerationResponse } from "@shared/schema";

interface TagResultsProps {
  result: TagGenerationResponse;
}

export default function TagResults({ result }: TagResultsProps) {
  const [copiedTag, setCopiedTag] = useState<string | null>(null);
  const { toast } = useToast();

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedTag(text);
      setTimeout(() => setCopiedTag(null), 2000);
      toast({
        title: "Copied!",
        description: "Tag copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy to clipboard.",
        variant: "destructive",
      });
    }
  };

  const copyAllTags = async () => {
    const allTags = result.generatedTags.join(", ");
    await copyToClipboard(allTags);
  };

  const getTagColors = (index: number) => {
    const colors = [
      "from-red-500/20 to-red-600/20 border-red-500/30 hover:from-red-500/30 hover:to-red-600/30",
      "from-orange-500/20 to-orange-600/20 border-orange-500/30 hover:from-orange-500/30 hover:to-orange-600/30",
      "from-yellow-500/20 to-yellow-600/20 border-yellow-500/30 hover:from-yellow-500/30 hover:to-yellow-600/30",
      "from-green-500/20 to-green-600/20 border-green-500/30 hover:from-green-500/30 hover:to-green-600/30",
      "from-blue-500/20 to-blue-600/20 border-blue-500/30 hover:from-blue-500/30 hover:to-blue-600/30",
      "from-purple-500/20 to-purple-600/20 border-purple-500/30 hover:from-purple-500/30 hover:to-purple-600/30",
      "from-pink-500/20 to-pink-600/20 border-pink-500/30 hover:from-pink-500/30 hover:to-pink-600/30",
      "from-indigo-500/20 to-indigo-600/20 border-indigo-500/30 hover:from-indigo-500/30 hover:to-indigo-600/30",
      "from-teal-500/20 to-teal-600/20 border-teal-500/30 hover:from-teal-500/30 hover:to-teal-600/30",
      "from-cyan-500/20 to-cyan-600/20 border-cyan-500/30 hover:from-cyan-500/30 hover:to-cyan-600/30",
      "from-lime-500/20 to-lime-600/20 border-lime-500/30 hover:from-lime-500/30 hover:to-lime-600/30",
      "from-emerald-500/20 to-emerald-600/20 border-emerald-500/30 hover:from-emerald-500/30 hover:to-emerald-600/30",
    ];
    return colors[index % colors.length];
  };

  return (
    <div className="mt-8">
      <div className="glass-morphism rounded-2xl p-6 border border-white/10">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-xl font-semibold text-white">Generated Tags</h4>
          <div className="flex space-x-3">
            <button 
              onClick={copyAllTags}
              className="glass-morphism px-4 py-2 rounded-lg text-sm font-medium text-white border border-white/20 hover:border-cyan-500/60 transition-all duration-300 glow-button"
            >
              <i className="fas fa-copy mr-1"></i>
              Copy All
            </button>
            <button 
              onClick={() => window.location.reload()}
              className="glass-morphism px-4 py-2 rounded-lg text-sm font-medium text-white border border-white/20 hover:border-pink-500/60 transition-all duration-300 glow-button"
            >
              <i className="fas fa-redo mr-1"></i>
              Regenerate
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {result.generatedTags.map((tag, index) => (
            <span
              key={index}
              onClick={() => copyToClipboard(tag)}
              className={`result-tag bg-gradient-to-r ${getTagColors(index)} px-3 py-2 rounded-lg text-sm font-medium text-white cursor-pointer transition-all duration-200 relative`}
            >
              {tag}
              {copiedTag === tag && (
                <span className="absolute -top-8 left-1/2 transform -translate-x-1/2 text-xs bg-green-500 text-white px-2 py-1 rounded">
                  Copied!
                </span>
              )}
            </span>
          ))}
        </div>
        
        <div className="mt-6 pt-6 border-t border-white/10">
          <div className="flex items-center justify-between text-sm text-gray-400">
            <span>Generated {result.generatedTags.length} tags for {result.platform.replace('-', ' ')}</span>
            <span>{new Date(result.createdAt).toLocaleTimeString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
