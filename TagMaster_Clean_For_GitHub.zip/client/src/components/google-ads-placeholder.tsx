interface GoogleAdsPlaceholderProps {
  type: 'banner' | 'medium-rectangle' | 'leaderboard';
  label: string;
  description: string;
  size: string;
  borderColor: string;
}

export default function GoogleAdsPlaceholder({ type, label, description, size, borderColor }: GoogleAdsPlaceholderProps) {
  const getContainerClass = () => {
    switch (type) {
      case 'banner':
        return 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16';
      case 'medium-rectangle':
        return 'max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mb-16';
      case 'leaderboard':
        return 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16';
      default:
        return 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16';
    }
  };

  const getPadding = () => {
    switch (type) {
      case 'medium-rectangle':
        return 'p-6';
      default:
        return 'p-8';
    }
  };

  return (
    <div className="relative z-10">
      <div className={getContainerClass()}>
        <div className={`glass-morphism rounded-2xl ${getPadding()} text-center border ${borderColor}`}>
          <div className="text-yellow-500/60 text-sm font-medium mb-2">{label}</div>
          <div className="text-gray-400">{description}</div>
          <div className="text-xs text-gray-500 mt-2">{size}</div>
        </div>
      </div>
    </div>
  );
}
