export default function Logo() {
  return (
    <div className="flex items-center space-x-3">
      <div className="text-4xl animate-lightning hover:animate-pulse cursor-pointer">⚡</div>
      <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-500 to-pink-500 bg-clip-text text-transparent">
        TagMaster
      </h1>
    </div>
  );
}
